﻿
using System.Data;
using System.Data.SqlClient;
using EmployeeManagement.Models;
using Microsoft.Extensions.Configuration;

public class EmployeeDAL
{
    //It is a variable declared at the class level
    //The readonly field is commonly used to store configuration values or other data that should remain constant for the lifetime of the class instance, such as connection strings, API keys, or settings
   
    private readonly string _connectionString;


    //Constructor ;a constructor is a special method in a class that is called automatically when an object of that class is created
    public EmployeeDAL(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("DefaultConnection");
    }


    public List<Employee> GetAllEmployee()
    {
        List<Employee> employeeList = new List<Employee>();

        using (SqlConnection con = new SqlConnection(_connectionString))
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "GetEmployees";

            SqlDataAdapter sqlDA = new SqlDataAdapter(cmd);
            DataTable dtEmployees = new DataTable();

            // Fill the DataTable (SqlDataAdapter manages connection)
            sqlDA.Fill(dtEmployees);

            foreach (DataRow dr in dtEmployees.Rows)
            {
                employeeList.Add(new Employee
                {
                    ID = dr["ID"] != DBNull.Value ? Convert.ToInt32(dr["ID"]) : 0,
                    Name = dr["Name"] != DBNull.Value ? dr["Name"].ToString() : string.Empty,
                    DateOfBirth = dr["DateOfBirth"] != DBNull.Value ? Convert.ToDateTime(dr["DateOfBirth"]) : DateTime.MinValue,
                    Email = dr["Email"] != DBNull.Value ? dr["Email"].ToString() : string.Empty,
                    Picture = dr["Picture"] != DBNull.Value ? dr["Picture"].ToString() : string.Empty
                });
            }
        }

        return employeeList;
    }

    public List<Employee> GetAllEmployeeById(int id)
    {
        List<Employee> employeeList = new List<Employee>();

        using (SqlConnection con = new SqlConnection(_connectionString))
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "GetEmployeeById";
            cmd.Parameters.AddWithValue("@ID", id);
            SqlDataAdapter sqlDA = new SqlDataAdapter(cmd);
            DataTable dtEmployees = new DataTable();

            // Fill the DataTable (SqlDataAdapter manages connection)
            sqlDA.Fill(dtEmployees);

            foreach (DataRow dr in dtEmployees.Rows)
            {
                employeeList.Add(new Employee
                {
                    ID = dr["ID"] != DBNull.Value ? Convert.ToInt32(dr["ID"]) : 0,
                    Name = dr["Name"] != DBNull.Value ? dr["Name"].ToString() : string.Empty,
                    DateOfBirth = dr["DateOfBirth"] != DBNull.Value ? Convert.ToDateTime(dr["DateOfBirth"]) : DateTime.MinValue,
                    Email = dr["Email"] != DBNull.Value ? dr["Email"].ToString() : string.Empty,
                    Picture = dr["Picture"] != DBNull.Value ? dr["Picture"].ToString() : string.Empty
                });
            }
        }

        return employeeList;
    }



    //Insert Employee
    public bool InsertEmployee(Employee employee)
    {
        int id = 0;
        using (SqlConnection con = new SqlConnection(_connectionString))
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "AddEmployee";

            cmd.Parameters.AddWithValue("@Name", employee.Name);
            cmd.Parameters.AddWithValue("@DateOfBirth", employee.DateOfBirth);
            cmd.Parameters.AddWithValue("@Email", employee.Email);
            cmd.Parameters.AddWithValue("@Picture", employee.Picture ?? (object)DBNull.Value); // Handle null picture

            con.Open();
          id=  cmd.ExecuteNonQuery();
            con.Close();
        }
        if (id > 0)
        {
            return true;
        }
        else
        {
            return false;
        }


    }

    public bool UpdateEmployee(Employee employee)
    {
        int i = 0;
        using (SqlConnection con = new SqlConnection(_connectionString))
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "UpdateEmployee";

            cmd.Parameters.AddWithValue("@ID", employee.ID);
            cmd.Parameters.AddWithValue("@Name", employee.Name);
            cmd.Parameters.AddWithValue("@DateOfBirth", employee.DateOfBirth);
            cmd.Parameters.AddWithValue("@Email", employee.Email);
            cmd.Parameters.AddWithValue("@Picture", employee.Picture ?? (object)DBNull.Value); // Handle null picture

            con.Open();
            i = cmd.ExecuteNonQuery();
            con.Close();
        }
        if (i > 0)
        {
            return true;
        }
        else
        {
            return false;
        }


    }


    public string DeleteEmployee(int id)
    {
        string result = "";

        using (SqlConnection con = new SqlConnection(_connectionString))
        {
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "DeleteEmployee";

            cmd.Parameters.AddWithValue("@ID", id);
            cmd.Parameters.Add("@OUTPUTMESSAGE", SqlDbType.VarChar, 50).Direction = ParameterDirection.Output;
            
            con.Open();
            cmd.ExecuteNonQuery();
            result = cmd.Parameters["@OUTPUTMESSAGE"].Value.ToString();
            con.Close();
        }
        return result;
       

    }

  
}

