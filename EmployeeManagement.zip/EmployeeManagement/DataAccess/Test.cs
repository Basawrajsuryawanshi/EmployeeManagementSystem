﻿namespace EmployeeManagement.DataAccess
{
    /*
    four pillars of OOP?
        Encapsulation: Hiding implementation details by restricting access to object members.
        Abstraction: Exposing only the essential features.
        Inheritance: Acquiring properties and behaviors from a parent class.
        Polymorphism: Performing a single action in different ways. 

     */

    public class Test
    {

    }

    // Encapsulation : Hiding implementation details by restricting access to object members.
    // Encapsulation ensures that the internal state of an object is protected and can only be modified in controlled ways.
    class BankAccount
    {
        private double balance; // Private field

        public double GetBalance() => balance; // Public method to access the private field
        public void Deposit(double amount) => balance += amount; // Controlled access

        public void Withdraw(double amount)
        {
            if (amount > balance) throw new InvalidOperationException("Insufficient funds");
            balance -= amount;
        }
    }

    // Inheritance and Polymorphism
    class Shape
    {
        public virtual double Area() => 0; // Virtual method
    }

    class Circle : Shape
    {
        public double Radius { get; set; }
        public override double Area() => Math.PI * Radius * Radius; // Polymorphism
    }

    class Rectangle : Shape
    {
        public double Width { get; set; }
        public double Height { get; set; }
        public override double Area() => Width * Height; // Polymorphism
    }

    // Abstraction through abstract classes
    abstract class Animal
    {
        public abstract void Speak();
    }

    class Dog : Animal
    {
        public override void Speak() => Console.WriteLine("Woof!");
    }

    class Cat : Animal
    {
        public override void Speak() => Console.WriteLine("Meow!");
    }

    /*
     What is the difference between an abstract class and an interface?
         Abstract Class: Can have concrete methods (implementation).
         Interface: Only method signatures, no implementation.
     */
    abstract class AbstractLogger
    {
        public abstract void Log(string message);
        public void CommonMethod() => Console.WriteLine("Common behavior");
    }

    interface ILogger
    {
        void Log(string message); // No implementation
    }

    // Implementation
    class ConsoleLogger : AbstractLogger, ILogger
    {
        public override void Log(string message) => Console.WriteLine($"Log: {message}");
    }

    /*
     What is the difference between override and new?
        override: Extends the base method behavior.
        new: Hides the base method.
     */

    /*
      How does the this keyword work?
        Refers to the current instance of the class.
     */

    class Employee
    {
        private string name;

        public Employee(string name) => this.name = name;

        public void PrintName() => Console.WriteLine($"Employee Name: {this.name}");
    }

}
