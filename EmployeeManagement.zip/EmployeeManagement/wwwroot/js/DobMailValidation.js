﻿$(document).ready(function () {
  
    debugger
    // Date of Birth Validation (DOB must not be greater than today's date)
    $("#DateOfBirth").on("change", function () {
        debugger
        var dob = new Date($(this).val());
        var today = new Date();
        today.setHours(0, 0, 0, 0);  // Reset the time to compare only the date

        $("#ErrorDateOfBirth").text("");

        if (dob > today) {
            //alert("Date of Birth cannot be greater than today's date.");
            // Show error message in the span
            $("#ErrorDateOfBirth").text("Date of Birth cannot be greater than today's date.");
            $(this).val(''); // Clear the input field if invalid

        }
    });

    // Email Validation (simple regex to validate email format)
    $("#Email").on("blur", function () {
        debugger
        var email = $(this).val();
        var emailRegex = /^[^\s]+[^\s]+\.[^\s]+$/;

        $("#errorEmail").text("");
        if (!emailRegex.test(email)) {
            //alert("Please enter a valid email address.");
            $("#errorEmail").text("Please enter a valid email address.");
            $(this).val(''); // Clear the input field if invalid
        }
    });
});