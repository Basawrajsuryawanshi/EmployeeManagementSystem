﻿using EmployeeManagement.Models;

namespace EmployeeManagement.ViewModels
{
    public class EmployeeIndexViewModel
    {
        public IEnumerable<Employee> Employees { get; set; }
        public Employee NewEmployee { get; set; }
    }
}
