﻿using EmployeeManagement.Models;
using EmployeeManagement.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace EmployeeManagement.Controllers
{
    public class EmployeeControllerCorrectWithoutViewModel : Controller
    {
        private readonly EmployeeDAL _dal;

        public EmployeeControllerCorrectWithoutViewModel(IConfiguration configuration)
        {
            _dal = new EmployeeDAL(configuration);
        }


        public IActionResult Index()
        {
            var employees = _dal.GetAllEmployee();
            if (employees.Count == 0)
            {
                TempData["InfoMessage"] = "Currently employees are not available in Database";
            }
            return View(employees);
        }

        //public IActionResult Index()
        //{
        //    var employees = _dal.GetAllEmployee(); // Fetch employees from the database
        //    var viewModel = new EmployeeIndexViewModel
        //    {
        //        Employees = employees,
        //        NewEmployee = new Employee() // Empty model for the create form
        //    };

        //    return View(viewModel);
        //}

        [HttpPost]
        public IActionResult Add(Employee employee)
        {
            // Logic to add an employee
            return RedirectToAction("Index");
        }



        public IActionResult Create()
        {
            // Logic to add an employee
            return View();
        }

        [HttpPost]
        public IActionResult Create(Employee employee, IFormFile Picture)
        {
            bool IsInserted = false;
            ModelState.Remove("Picture");
            try
            {
                if (ModelState.IsValid)
                {

                    if (Picture != null && Picture.Length > 0)
                    {
                        string fileName = Guid.NewGuid().ToString() + Path.GetExtension(Picture.FileName);
                        string filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/images", fileName);

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            Picture.CopyTo(stream);
                        }

                        // Store the relative path in Employee.Picture
                        employee.Picture = "/images/" + fileName;
                    }


                    IsInserted = _dal.InsertEmployee(employee);

                    if (IsInserted)
                    {
                        TempData["successMessage"] = "Employee details saved successfully";
                    }
                    else
                    {
                        TempData["ErrorMessage"] = "Unable to save employee details";
                    }
                }
                return RedirectToAction("Index");

            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = ex.Message;
                return View();
            }
        }

        //[HttpPost]
        //public IActionResult Create(EmployeeIndexViewModel model, IFormFile Picture)
        //{
        //    bool isInserted = false;
        //    ModelState.Remove("NewEmployee.Picture"); // Adjust to match view model structure

        //    try
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            var employee = model.NewEmployee; // Extract the NewEmployee object

        //            if (Picture != null && Picture.Length > 0)
        //            {
        //                string fileName = Guid.NewGuid().ToString() + Path.GetExtension(Picture.FileName);
        //                string filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/images", fileName);

        //                using (var stream = new FileStream(filePath, FileMode.Create))
        //                {
        //                    Picture.CopyTo(stream);
        //                }

        //                // Store the relative path in Employee.Picture
        //                employee.Picture = "/images/" + fileName;
        //            }

        //            isInserted = _dal.InsertEmployee(employee);

        //            if (isInserted)
        //            {
        //                TempData["successMessage"] = "Employee details saved successfully";
        //            }
        //            else
        //            {
        //                TempData["ErrorMessage"] = "Unable to save employee details";
        //            }
        //        }

        //        return RedirectToAction("Index");
        //    }
        //    catch (Exception ex)
        //    {
        //        TempData["ErrorMessage"] = ex.Message;
        //        return View();
        //    }
        //}

        public IActionResult Edit(int id)
        {
            var employees = _dal.GetAllEmployeeById(id).FirstOrDefault();
            if (employees == null)
            {
                TempData["InfoMessage"] = "employee not available with id :" + id.ToString();
                return RedirectToAction("Index");
            }
            // Logic to add an employee
            return View(employees);
        }

        [HttpPost,ActionName("Edit")]
        public IActionResult UpdateEmployee(Employee employee, IFormFile Picture)
        {
            try
            {
                ModelState.Remove("Picture");
                if (ModelState.IsValid)
                {
                    if (Picture != null && Picture.Length > 0)
                    {
                        string fileName = Guid.NewGuid().ToString() + Path.GetExtension(Picture.FileName);
                        string filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/images", fileName);

                        using (var stream = new FileStream(filePath, FileMode.Create))
                        {
                            Picture.CopyTo(stream);
                        }

                        // Store the relative path in Employee.Picture
                        employee.Picture = "/images/" + fileName;
                    }


                    bool isUpdated = _dal.UpdateEmployee(employee);



                    if (isUpdated)
                    {
                        TempData["successMessage"] = "Employee details updated successfully";
                    }
                    else
                    {
                        TempData["ErrorMessage"] = "Unable to update employee details";
                    }
                }
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = ex.Message;
                return View();
            }
        }


   

        [HttpGet]
        public IActionResult DeleteEmployee(int id)
        {
            _dal.DeleteEmployee(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var employee= _dal.GetAllEmployeeById(id).FirstOrDefault();

            try
            {
                if (employee == null)
                {
                    TempData["InfoMessage"] = "Employee not available with id:" + id.ToString();
                    return RedirectToAction("Index");
                }
                return View(employee);
            }
            catch (Exception ex)
            {

                TempData["ErrorMessage"] = ex.Message;
                return View();
            }
            
        }

        [HttpPost,ActionName("Delete")]
        public IActionResult Deleteconfirmation(int id)
        {
            string result = _dal.DeleteEmployee(id);





            try
            {
                if (result.Contains("deleted"))
                {
                    TempData["successMessage"] = result;
                    //return RedirectToAction("Index");
                }
                else
                {
                    TempData["ErrorMessage"] = result;
                }
                return RedirectToAction("Index");
               
            }
            catch (Exception ex)
            {

                TempData["ErrorMessage"] = ex.Message;
                return View();
            }

        }
    }
}
